export interface ToppingModel {
    toppings: [];
}